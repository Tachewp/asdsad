from flask import Blueprint, render_template, request, Response
from flask_login import login_user, login_required, logout_user, current_user
from . import db
from werkzeug.utils import secure_filename

views = Blueprint('views', __name__)

@views.route('/')
@login_required
def home():
    return render_template("home.html", user=current_user)