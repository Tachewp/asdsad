from flask import Blueprint, render_template, request, flash, redirect, url_for, Flask
from .models import User
from . import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, login_required, logout_user, current_user

from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField
from werkzeug.utils import secure_filename
import os
from wtforms.validators import InputRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'foartesecret'
app.config['UPLOAD_FOLDER'] = 'static'


auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()
        if user:
            if check_password_hash(user.password, password):
                flash('Logged in!', category='success')
                login_user(user, remember=True)
                return redirect(url_for('views.home'))
            else:
                flash('Incorrect password!', category='error')
        else:
            flash('Incorrect email!', category='error')
    return render_template("login.html", user=current_user)

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists!', category='error')
        elif len(email) < 4:
            flash('Email must have at least 4 characters', category='error')
        elif len(first_name) < 2:
            flash('firstName must have at least 2 characters', category='error')
        elif password1 != password2:
            flash('Passwords do not match', category='error')
        elif len(password1) < 5:
            flash('Password must have at least 5 characters', category='error')
        else:
            new_user = User(email=email, first_name=first_name, password=generate_password_hash(
                password1, method='pbkdf2:sha256:600000'))
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Your account has been created', category='success')
            return redirect(url_for('views.home'))
    return render_template("sign-up.html", user=current_user)
@auth.route('/about')
@login_required
def aboutme():
    return render_template("aboutme.html", user=current_user)


class UploadFileForm(FlaskForm):
    file = FileField("File", validators=[InputRequired()])
    submit = SubmitField("Upload File")

@auth.route('/upload', methods=["GET", "POST"])
@login_required
def uploadfile():
    form = UploadFileForm()
    if form.validate_on_submit():
        file = form.file.data
        file_name = request.form.get('file_name')
        if file_name:
            file.filename = file_name 
        file.save(os.path.join(os.path.abspath(os.path.dirname(__file__)), app.config['UPLOAD_FOLDER'], secure_filename(file.filename)))
        return redirect('/gallery')
    return render_template('upload.html', form=form, user=current_user)

def get_picture_urls():
    picture_folder = './website/static'
    picture_files = os.listdir(picture_folder)
    return [f'/static/{file}' for file in picture_files if file.endswith(('.jpg', '.png', '.jpeg'))]

current_index = 0  # Index of the current picture

@auth.route('/gallery', methods=["GET", "POST"])
def printPictures():
    global current_index
    picture_urls = get_picture_urls()
    
    if not picture_urls:
        current_picture = None
    else:
        current_index = min(current_index, len(picture_urls) - 1)
        current_picture = picture_urls[current_index]

    return render_template('gallery.html', current_picture=current_picture, current_index=current_index, picture_urls=picture_urls, user=current_user)

@auth.route('/navigate_picture', methods=['POST'])
def navigate_picture():
    direction = request.form.get('direction')
    global current_index
    picture_urls = get_picture_urls()

    if not picture_urls:
        current_index = 0
    else:
        if direction == 'prev' and current_index > 0:
            current_index -= 1
        elif direction == 'next' and current_index < len(picture_urls) - 1:
            current_index += 1

    return redirect('/gallery')

@auth.route('/delete_picture', methods=['POST'])
@login_required
def delete_picture():
    allowed_user = 'george@gmail.com'
    if current_user.email == allowed_user:
        picture_url = request.form.get('url')
        picture_path = os.path.join(app.static_folder, os.path.basename(picture_url))
        
        if os.path.exists(picture_path):
            os.remove(picture_path)
            picture_urls = get_picture_urls()
            current_index = picture_urls.index(picture_url) if picture_url in picture_urls else 0
            current_index = min(current_index, len(picture_urls) - 1)  # Ensure current_index is within range

            return redirect('/gallery')  # Redirect to the gallery page after deletion
        else:
            return 'Picture not found', 404
    else:
        flash('You are not allowed to delete a picture from the gallery!', 'error')
        return redirect('/')
